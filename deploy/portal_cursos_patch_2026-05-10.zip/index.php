<?php use App\Core\Helpers; ?>

<section class="page-header">
    <h1>Cursos e eventos</h1>
    <p>Confira apenas cursos ativos do portal. O frontend não publica itens inativos nem dados operacionais do backoffice.</p>
</section>

<section class="card-grid">
    <?php if (empty($cursos)): ?>
        <article class="status-card">
            <strong>Nenhum curso ativo</strong>
            <span>O catalogo ainda não possui itens publicos disponiveis.</span>
        </article>
    <?php else: ?>
        <?php foreach ($cursos as $curso): ?>
            <article class="course-card">
                <?php if (!empty($curso['thumbnail'])): ?>
                    <div class="course-card__image">
                        <img src="<?php echo Helpers::e($curso['thumbnail']); ?>" alt="<?php echo Helpers::e($curso['nome']); ?>">
                    </div>
                <?php endif; ?>
                <div class="course-card__media">
                    <strong><?php echo Helpers::e($curso['nome']); ?></strong>
                    <span><?php echo Helpers::e($curso['categoria_nome'] ?: 'Sem categoria'); ?></span>
                </div>
                <div class="course-card__body">
                    <div class="pill-row">
                        <span class="pill"><?php echo Helpers::e($curso['tipo']); ?></span>
                        <span class="pill"><?php echo Helpers::e($curso['modalidade']); ?></span>
                        <?php if (!empty($curso['professor_responsavel']['nome'])): ?>
                            <span class="pill">Professor: <?php echo Helpers::e($curso['professor_responsavel']['nome']); ?></span>
                        <?php endif; ?>
                        <?php if (!empty($curso['em_promocao'])): ?>
                            <span class="pill pill--alert">Promoção</span>
                        <?php endif; ?>
                    </div>
                    <p><?php echo Helpers::e($curso['descricao_curta'] ?: 'Descrição resumida em breve.'); ?></p>
                    <div class="course-card__meta">
                        <span><?php echo (int) $curso['total_turmas_abertas']; ?> turma(s) aberta(s)</span>
                        <?php if (!empty($curso['desconto_promocional'])): ?>
                            <div>
                                <span class="muted" style="font-size:12px;text-decoration:line-through;">R$ <?php echo number_format((float) $curso['valor'], 2, ',', '.'); ?></span>
                                <strong style="display:block;">R$ <?php echo number_format((float) $curso['valor_efetivo'], 2, ',', '.'); ?></strong>
                            </div>
                        <?php else: ?>
                            <strong>R$ <?php echo number_format((float) ($curso['valor_efetivo'] ?? $curso['valor']), 2, ',', '.'); ?></strong>
                        <?php endif; ?>
                    </div>
                    <div class="cta-group">
                        <a class="button-link button-link--ghost" href="/cursos/detalhe?curso_id=<?php echo (int) $curso['id']; ?>">Ver detalhes</a>
                        <?php if (!empty($curso['turmas_abertas'][0]['id'])): ?>
                            <a class="button-link" href="/inscricao?curso_id=<?php echo (int) $curso['id']; ?>&turma_id=<?php echo (int) $curso['turmas_abertas'][0]['id']; ?>">Inscreva-se já</a>
                        <?php endif; ?>
                    </div>
                </div>
            </article>
        <?php endforeach; ?>
    <?php endif; ?>
</section>

